import React from "react";
import UserProfileComponent from "../components/UserProfileComponent";

const UserProfilePage = () => {
  return <UserProfileComponent />;
};

export default UserProfilePage;
