import React from "react";
import SecondFactorAuthenticationComponent from "../components/SecondFactorAuthenticationComponent";

export default function SecondFactorAuthenticationPage() {
  return (
    <div>
      <SecondFactorAuthenticationComponent />
    </div>
  );
}
