import React from "react";
import LoginComponent from "../components/LoginComponent";

export default function LoginPage() {
  return (
    <div>
      <LoginComponent />
    </div>
  );
}
