import React from "react";
import RegisterationComponent from "../components/RegistrationComponent";

export default function RegistrationPage() {
  return (
    <div>
      <RegisterationComponent />
    </div>
  );
}
