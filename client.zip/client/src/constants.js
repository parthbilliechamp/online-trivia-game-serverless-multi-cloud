export const AWS_API_GATEWAY_URL = 'https://tahlvi1agg.execute-api.us-east-1.amazonaws.com/dev';
export const GCP_API_GATEWAY_URL = 'https://gateway2-9tr16481.ue.gateway.dev';
export const GCP_API_GATEWAY_KEY = 'AIzaSyBVsdUsoFIavwCc-bpGCDKFRpQciwWQrH0'

export const APP_LOGIN_URL = `https://trivia-quiz.auth.us-east-1.amazoncognito.com/login?client_id=umlids9prbksb5eupfj18blsd&response_type=code&scope=aws.cognito.signin.user.admin+email+openid+phone+profile&redirect_uri=https%3A%2F%2Ffrontendapp-7l4cel6fjq-ue.a.run.app%2Flogin%2F`;

export const APP_LOGOUT_URL = `https://trivia-quiz.auth.us-east-1.amazoncognito.com/login?response_type=code&client_id=umlids9prbksb5eupfj18blsd&redirect_uri=https%3A%2F%2Ffrontendapp-7l4cel6fjq-ue.a.run.app%2Flogin%2F&state=STATE&scope=openid+profile+aws.cognito.signin.user.admin`

export const AWS_ACCESS_KEY_ID = 'ASIATJZBBY7BRXDCKFSL';
export const AWS_SECRET_ACCESS_KEY = 'XFKcWWF1vEzf3ZJo3sr+HZpNqRCeJk4QOaVOO7c+';
export const AWS_SESSION_TOKEN = 'FwoGZXIvYXdzEIH//////////wEaDBGE7z6MXJZ9RQKu0yLCAYIGL6bd9NwrwekM3QKBQ2lHnXGZqgBc/q+PqG9saTIqzAhfcVB8gTq0epD7/A128RhqSpdsu/EITSczI/gPDMzRS/aFKTneZRblehUduMWP62Tt2ZU0NoAC6yXUOEUa5dL7A+1icbAQlr9aWgF+p4Kf2F9pATxQLv3jBGXwCEd5ruaZ1Qie4AsyMl6tmXqdW7z/tc+BSxsNcQFxBb65Ls1CCOxFZMkzDEGCJ1RGjuMfdpxnXbcNSZdXX6eG/KgE9Hg6KJKFr6YGMi19ACYnQOFKeZqVMPM+gopM4eTaeI1dhF+ImkdSSlnVD/nH/tDXud+XbohdWE0=';
